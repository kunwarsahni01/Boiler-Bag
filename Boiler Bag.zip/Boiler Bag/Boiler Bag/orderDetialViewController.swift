//
//  orderDetialViewController.swift
//  Boiler Bag
//
//  Created by Kunwar Sahni on 9/15/19.
//  Copyright © 2019 hello world. All rights reserved.
//

import UIKit

class orderDetialViewController: UIViewController {
    
    var orderNumber: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(orderNumber)
    }
}
